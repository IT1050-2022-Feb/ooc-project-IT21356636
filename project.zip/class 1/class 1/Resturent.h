#pragma once
#include <iostream>
#include<string>
using namespace std;

class Resturent
{
private:
	char regNo;
	string name;
	string location;
	string email;
	int phoneNo;
	
	
	
public:
	Resturent();
	Resturent(string rregNo, string rname, string rlocation, string remail, int rphoneNo);
	void setResturentNo();
	void addResturent(Resturent * r1, Resturent * r2);
	void removeResturent();
	~Resturent();

};

