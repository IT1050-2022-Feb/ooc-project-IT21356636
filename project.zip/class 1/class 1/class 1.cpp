// class 1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Resturent.h"
#include <iostream>
using namespace std;

int main()
{
	Resturent r1;
	r1.setResturentNo();
	r1.addResturent();
	void removeResturent();


	Resturent r2;
	r2.setResturentNo();
	r2.addResturent();
	void removeResturent();


    return 0;
}

