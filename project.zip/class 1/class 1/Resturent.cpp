#include "stdafx.h"
#include "Resturent.h"//Resturent class
#include<iostream>
#include <string>
#include<iomanip>
#define SIZE;//define
using namespace std;

Resturent::Resturent()//Default Constructor
{
	regNo = 0;
	name[20] = 0;
	location = 0;
	email = 0;
	phoneNo = 0;
	
}

Resturent::Resturent(string regNo, string rname, string rlocation, string remail, int rphoneNo)
{
	regNo = regNo;
	name = rname;
	location = rlocation;
	email = remail;
	phoneNo = rphoneNo;
}


void Resturent::setResturentNo()//Methods
{

}

void Resturent::addResturent(Resturent* r1,Resturent* r2)//Methods
{

}



void Resturent::removeResturent()//Methods
{

}

Resturent::~Resturent()
{

}
