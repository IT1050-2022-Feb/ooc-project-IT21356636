// class2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Menu_card.h"
#include <iostream>
using namespace std;

int main()
{
	Menu_card m1(10, "vegetarian", 2000); 
	m1.setItem();
	void deleteItem();

	Menu_card m2(100, "Pizza", 2500);
	m2.setItem();
	void deleteItem();

    return 0;
}

