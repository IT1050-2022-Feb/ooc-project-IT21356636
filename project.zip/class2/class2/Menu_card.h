#pragma once
#include <string>
using namespace std;

class Menu_card // class name
{
private://Atributes
	int itemID;
	string name;
	float price;

public://Method
	Menu_card();
	Menu_card(int itemID, string name, float price);
	void setItem(Menu_card* m1, Menu_card* m2);
	void deleteItem();
	~Menu_card();
};

