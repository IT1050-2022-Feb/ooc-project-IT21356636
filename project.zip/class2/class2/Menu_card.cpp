#include "stdafx.h"
#include "Menu_card.h"
#include <string>
#include <iostream>
using namespace std;

Menu_card::Menu_card()//Default Constructor
{
	itemID = 0;
	name = "";
	price = 0;

}

Menu_card::Menu_card(int fitemID, string fname, float fprice)//Overload Constructor
{
	itemID = fitemID;
	name = fname;
	price = fprice;
}

void Menu_card::setItem(Menu_card * m1, Menu_card * m2)
{

}


void Menu_card::deleteItem()//Method
{
}

Menu_card::~Menu_card()
{
}
